from library import Book,Library
from ui import library_ui
from test import run_tests

if __name__ == "__main__":
    run_tests()
    library_ui()